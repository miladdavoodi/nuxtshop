<?php

echo '$a != $b';
